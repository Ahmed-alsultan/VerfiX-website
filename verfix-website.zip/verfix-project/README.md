# VerfiX Website — Production Build

Swiss Trust Infrastructure for Regulated Industries  
**verfix.swiss**

---

## Project Structure

```
verfix-website/
├── index.html              ← Main website (upload this as homepage)
├── robots.txt              ← SEO crawler rules
├── sitemap.xml             ← Search engine sitemap
├── .htaccess               ← Apache: HTTPS redirect, headers, caching
├── _headers                ← Netlify / Cloudflare Pages headers
├── _redirects              ← Netlify routing
├── vercel.json             ← Vercel deployment config
├── DEPLOY.md               ← Full deployment instructions
│
├── assets/
│   ├── images/
│   │   ├── verfix-logo.png          ← Nav logo (transparent background)
│   │   ├── verfix-logo--footer.png  ← Footer logo (white text, transparent bg)
│   │   └── og-image.jpg             ← Social sharing image (1200×630)
│   ├── team/
│   │   ├── ahmed-sherwed.jpeg       ← Ahmed Sherwed — Founder & CEO
│   │   ├── manel-mhamdi.jpeg        ← Manel Mhamdi — Business Development
│   │   └── petter-stahle.jpeg       ← Petter Stahle — AI & Technology Lead
│   └── schema.json                  ← JSON-LD structured data (reference)
│
├── css/
│   └── main.css            ← All styles (extracted from index.html)
│
└── js/
    └── main.js             ← All JavaScript (extracted from index.html)
```

---

## Quick Deploy (5 minutes)

### Netlify (Recommended)
1. Drag and drop the **entire folder** to [netlify.com](https://netlify.com)
2. Add domain `verfix.swiss` in Site Settings → Domain Management
3. HTTPS is automatic ✓

### Vercel
1. Upload to [vercel.com](https://vercel.com)
2. Add domain in Project Settings → Domains

### Apache / cPanel
1. Upload all files to `public_html/`
2. `.htaccess` handles HTTPS and caching automatically

---

## After Deployment

- Submit sitemap: `https://verfix.swiss/sitemap.xml` to Google Search Console
- Test OG preview: [opengraph.xyz](https://opengraph.xyz)
- Validate structured data: [search.google.com/test/rich-results](https://search.google.com/test/rich-results)
- Connect contact form to Netlify Forms, Formspree, or your backend

---

## Technical Notes

- Single-page application — all pages in `index.html`
- All team photos embedded as external files (no base64 bloat)
- EN/DE/FR multilingual via JS translation system
- Font Awesome 6.5.0 loaded from CDN
- Google Fonts: Bricolage Grotesque + IBM Plex Mono

---

*VerfiX AG · Switzerland · hello@verfix.swiss*
