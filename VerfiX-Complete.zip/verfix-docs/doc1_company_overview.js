const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
  ShadingType, VerticalAlign, PageNumber, LevelFormat, PageBreak,
  TabStopType, TabStopPosition
} = require('docx');
const fs = require('fs');

// ── Brand colours ─────────────────────────────────────────
const RED    = 'C8252A';
const DARK   = '1A1F2E';
const MID    = '4B5563';
const LIGHT  = 'F3F4F6';
const WHITE  = 'FFFFFF';
const BORDER = { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' };
const BORDERS = { top: BORDER, bottom: BORDER, left: BORDER, right: BORDER };
const NO_BORDER = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
const NO_BORDERS = { top: NO_BORDER, bottom: NO_BORDER, left: NO_BORDER, right: NO_BORDER };

// ── Helpers ────────────────────────────────────────────────
const sp = (before=0, after=0) => ({ spacing: { before, after } });
const h1 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_1,
  children: [new TextRun({ text, bold: true, size: 32, color: DARK, font: 'Arial' })],
  ...sp(280, 120)
});
const h2 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_2,
  children: [new TextRun({ text, bold: true, size: 26, color: RED, font: 'Arial' })],
  ...sp(220, 80)
});
const h3 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_3,
  children: [new TextRun({ text, bold: true, size: 22, color: DARK, font: 'Arial' })],
  ...sp(160, 60)
});
const body = (text, opts={}) => new Paragraph({
  children: [new TextRun({ text, size: 22, color: MID, font: 'Arial', ...opts })],
  ...sp(60, 60)
});
const bullet = (text) => new Paragraph({
  numbering: { reference: 'bullets', level: 0 },
  children: [new TextRun({ text, size: 22, color: MID, font: 'Arial' })],
  ...sp(40, 40)
});
const redLine = () => new Paragraph({
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: RED, space: 1 } },
  children: [new TextRun('')],
  ...sp(0, 120)
});
const blank = (n=1) => Array.from({length:n}, () => new Paragraph({ children: [new TextRun('')] }));

// ── Table helpers ──────────────────────────────────────────
const W = 9360; // content width in DXA (US Letter 1" margins)
const cell = (text, opts={}) => new TableCell({
  borders: BORDERS,
  width: { size: opts.w || Math.floor(W/2), type: WidthType.DXA },
  shading: opts.shade ? { fill: opts.shade, type: ShadingType.CLEAR } : undefined,
  margins: { top: 100, bottom: 100, left: 140, right: 140 },
  verticalAlign: VerticalAlign.TOP,
  children: [new Paragraph({
    children: [new TextRun({
      text,
      size: opts.size || 20,
      bold: opts.bold || false,
      color: opts.color || MID,
      font: 'Arial'
    })],
    alignment: opts.align || AlignmentType.LEFT,
    spacing: { before: 20, after: 20 }
  })]
});

const headerRow = (texts, widths) => new TableRow({
  children: texts.map((t, i) => new TableCell({
    borders: BORDERS,
    width: { size: widths[i], type: WidthType.DXA },
    shading: { fill: DARK, type: ShadingType.CLEAR },
    margins: { top: 100, bottom: 100, left: 140, right: 140 },
    children: [new Paragraph({
      children: [new TextRun({ text: t, bold: true, size: 20, color: WHITE, font: 'Arial' })],
      spacing: { before: 20, after: 20 }
    })]
  }))
});

const dataRow = (texts, widths, shade=false) => new TableRow({
  children: texts.map((t, i) => new TableCell({
    borders: BORDERS,
    width: { size: widths[i], type: WidthType.DXA },
    shading: shade ? { fill: LIGHT, type: ShadingType.CLEAR } : undefined,
    margins: { top: 100, bottom: 100, left: 140, right: 140 },
    children: [new Paragraph({
      children: [new TextRun({ text: t, size: 20, color: MID, font: 'Arial' })],
      spacing: { before: 20, after: 20 }
    })]
  }))
});

// ── PAGE BREAK ─────────────────────────────────────────────
const pageBreak = () => new Paragraph({
  children: [new PageBreak()]
});

// ══════════════════════════════════════════════════════════
// DOCUMENT 1: COMPANY OVERVIEW
// ══════════════════════════════════════════════════════════
const doc = new Document({
  numbering: {
    config: [
      { reference: 'bullets',
        levels: [{ level: 0, format: LevelFormat.BULLET, text: '\u2022',
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: 'numbers',
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.',
          alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }
    ]
  },
  styles: {
    default: { document: { run: { font: 'Arial', size: 22, color: MID } } },
    paragraphStyles: [
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 32, bold: true, color: DARK, font: 'Arial' },
        paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 0 } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 26, bold: true, color: RED, font: 'Arial' },
        paragraph: { spacing: { before: 220, after: 80 }, outlineLevel: 1 } },
      { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 22, bold: true, color: DARK, font: 'Arial' },
        paragraph: { spacing: { before: 160, after: 60 }, outlineLevel: 2 } }
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    headers: {
      default: new Header({
        children: [
          new Paragraph({
            children: [
              new TextRun({ text: 'VerfiX AG  ', bold: true, size: 18, color: DARK, font: 'Arial' }),
              new TextRun({ text: '|  Company Overview', size: 18, color: MID, font: 'Arial' }),
              new TextRun({ text: '\t', size: 18 }),
              new TextRun({ text: 'Confidential', size: 16, color: MID, font: 'Arial', italics: true })
            ],
            tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
            border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: RED, space: 1 } }
          })
        ]
      })
    },
    footers: {
      default: new Footer({
        children: [
          new Paragraph({
            children: [
              new TextRun({ text: 'verfix.ch  |  contact@verfix.ch', size: 16, color: MID, font: 'Arial' }),
              new TextRun({ text: '\t', size: 16 }),
              new TextRun({ text: 'Page ', size: 16, color: MID, font: 'Arial' }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, color: MID, font: 'Arial' })
            ],
            tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
            border: { top: { style: BorderStyle.SINGLE, size: 2, color: 'CCCCCC', space: 1 } }
          })
        ]
      })
    },
    children: [

      // ── COVER ──────────────────────────────────────────────
      new Paragraph({
        children: [new TextRun({ text: '', size: 22 })],
        spacing: { before: 1440, after: 0 }
      }),
      new Paragraph({
        children: [new TextRun({ text: 'VerfiX AG', bold: true, size: 72, color: RED, font: 'Arial' })],
        alignment: AlignmentType.LEFT,
        spacing: { before: 0, after: 120 }
      }),
      new Paragraph({
        children: [new TextRun({ text: 'Company Overview', bold: true, size: 48, color: DARK, font: 'Arial' })],
        alignment: AlignmentType.LEFT,
        spacing: { before: 0, after: 80 }
      }),
      new Paragraph({
        border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: RED, space: 1 } },
        children: [new TextRun('')],
        spacing: { before: 0, after: 240 }
      }),
      new Paragraph({
        children: [new TextRun({
          text: 'Swiss Identity Infrastructure for Regulated Industries',
          size: 28, color: MID, font: 'Arial', italics: true
        })],
        spacing: { before: 0, after: 480 }
      }),

      // Cover metadata table
      new Table({
        width: { size: 5400, type: WidthType.DXA },
        columnWidths: [1800, 3600],
        rows: [
          new TableRow({ children: [
            new TableCell({ borders: NO_BORDERS, width: { size: 1800, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Document', size: 18, bold: true, color: MID, font: 'Arial' })] })] }),
            new TableCell({ borders: NO_BORDERS, width: { size: 3600, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 0 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Company Overview', size: 18, color: MID, font: 'Arial' })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: NO_BORDERS, width: { size: 1800, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Version', size: 18, bold: true, color: MID, font: 'Arial' })] })] }),
            new TableCell({ borders: NO_BORDERS, width: { size: 3600, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 0 },
              children: [new Paragraph({ children: [new TextRun({ text: '1.0', size: 18, color: MID, font: 'Arial' })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: NO_BORDERS, width: { size: 1800, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Date', size: 18, bold: true, color: MID, font: 'Arial' })] })] }),
            new TableCell({ borders: NO_BORDERS, width: { size: 3600, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 0 },
              children: [new Paragraph({ children: [new TextRun({ text: 'June 2025', size: 18, color: MID, font: 'Arial' })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: NO_BORDERS, width: { size: 1800, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Classification', size: 18, bold: true, color: MID, font: 'Arial' })] })] }),
            new TableCell({ borders: NO_BORDERS, width: { size: 3600, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 0 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Confidential — For Recipient Use Only', size: 18, color: RED, font: 'Arial', bold: true })] })] })
          ]}),
          new TableRow({ children: [
            new TableCell({ borders: NO_BORDERS, width: { size: 1800, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 120 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Contact', size: 18, bold: true, color: MID, font: 'Arial' })] })] }),
            new TableCell({ borders: NO_BORDERS, width: { size: 3600, type: WidthType.DXA },
              margins: { top: 60, bottom: 60, left: 0, right: 0 },
              children: [new Paragraph({ children: [new TextRun({ text: 'contact@verfix.ch  |  verfix.ch', size: 18, color: MID, font: 'Arial' })] })] })
          ]})
        ]
      }),

      pageBreak(),

      // ── EXECUTIVE SUMMARY ─────────────────────────────────
      h1('Executive Summary'),
      redLine(),
      body('VerfiX AG is a Swiss identity infrastructure company that provides identity verification, business verification, risk scoring, and AML compliance capabilities to regulated organisations in Switzerland and Europe.'),
      body('The company operates the VerfiX platform — a modular, API-first identity infrastructure designed to meet the compliance requirements of Swiss and European regulated industries. The platform processes identity verification decisions, business verification checks, and risk scoring using a combination of document analysis, biometric verification, and automated AML screening, with all data processing conducted exclusively in Switzerland.'),
      body('VerfiX is positioned as Swiss-first identity infrastructure, addressing the specific requirements of organisations subject to FINMA supervision, the Swiss Federal Act on Combating Money Laundering (GwG), and the revised Federal Act on Data Protection (nFADP), while also supporting organisations with GDPR obligations.'),
      body('This document provides an overview of the company, its products, target markets, technical capabilities, and regulatory positioning for enterprise evaluation purposes.'),

      ...blank(),

      // ── COMPANY AT A GLANCE TABLE ──────────────────────────
      h2('Company at a Glance'),
      new Table({
        width: { size: W, type: WidthType.DXA },
        columnWidths: [2600, 6760],
        rows: [
          headerRow(['Attribute', 'Detail'], [2600, 6760]),
          dataRow(['Company name', 'VerfiX AG'], [2600, 6760], false),
          dataRow(['Headquarters', 'Switzerland'], [2600, 6760], true),
          dataRow(['Jurisdiction', 'Swiss law'], [2600, 6760], false),
          dataRow(['Industry', 'Identity Verification / RegTech / Trust Infrastructure'], [2600, 6760], true),
          dataRow(['Products', 'KYC, KYB, eID Gateway, Trust Engine'], [2600, 6760], false),
          dataRow(['Deployment options', 'Cloud (Swiss-hosted), Private Cloud, On-Premise'], [2600, 6760], true),
          dataRow(['Data residency', 'Switzerland (all processing and storage)'], [2600, 6760], false),
          dataRow(['Regulatory alignment', 'nFADP, FINMA Circular 2016/7, GwG, GDPR-aligned'], [2600, 6760], true),
          dataRow(['Primary markets', 'Banking, Fintech, Crypto, Insurance, Telecom, Government, Mobility'], [2600, 6760], false),
          dataRow(['Integration', 'REST API, SDKs (planned), Webhooks'], [2600, 6760], true),
          dataRow(['Website', 'https://verfix.ch'], [2600, 6760], false),
          dataRow(['Contact', 'contact@verfix.ch'], [2600, 6760], true),
        ]
      }),

      ...blank(),

      // ── MISSION AND VISION ────────────────────────────────
      h2('Mission and Vision'),
      h3('Mission'),
      body('Build the trust layer for digital identity verification in Switzerland and Europe.'),
      h3('Vision'),
      body('To become the standard identity infrastructure for regulated industries across Switzerland and Europe — enabling every regulated organisation to verify who they are dealing with, confidently and in compliance, through a single Swiss-hosted platform.'),
      h3('Positioning'),
      body('VerfiX occupies a differentiated position in the identity verification market: Swiss-first. While international identity verification providers offer global coverage from non-Swiss infrastructure, VerfiX is designed, built, and operated specifically for organisations that must comply with Swiss law, FINMA supervision, and Swiss data residency requirements. This makes VerfiX the natural choice for Swiss cantonal banks, Swiss fintechs, Swiss crypto platforms, and any regulated entity for which data sovereignty is a procurement requirement, not an option.'),

      ...blank(),

      // ── THE PROBLEM ───────────────────────────────────────
      h2('The Problem VerfiX Solves'),
      body('Regulated organisations in Switzerland face a compliance environment that is more demanding than most, and growing more so. Following Switzerland\'s designation on the FATF grey list in 2024, FINMA has intensified supervision of KYC and AML programmes across all regulated sectors. At the same time, the revised nFADP introduced new obligations for organisations processing biometric data.'),
      body('Existing identity verification solutions present three categories of difficulty for Swiss regulated entities:'),
      bullet('Data sovereignty: Most major identity verification providers process and store data outside Switzerland, creating compliance risk under nFADP and FINMA supervisory expectations. Transferring biometric data to non-Swiss infrastructure requires explicit legal basis and enhanced documentation.'),
      bullet('Swiss document and compliance coverage: International providers are optimised for the largest global markets. Swiss-specific document types, cantonal nuances, Swiss-German language support for voice biometrics, and alignment with GwG, FINMA, and nFADP require specific configuration that generic providers do not offer as standard.'),
      bullet('Integration with Swiss systems: Swiss organisations use core banking systems, ERP platforms, and compliance tools that require integration patterns and data formats specific to the Swiss market. Generic API documentation does not address these requirements.'),
      body('VerfiX addresses all three problems through a platform designed specifically for the Swiss regulatory environment, operated exclusively on Swiss infrastructure, with Swiss compliance built in by design rather than added as a configuration option.'),

      ...blank(),

      // ── PRODUCTS ─────────────────────────────────────────
      h2('Core Products'),
      body('The VerfiX platform comprises four integrated product modules. Each module can be used independently or as part of a unified onboarding and compliance workflow.'),

      // Products table
      new Table({
        width: { size: W, type: WidthType.DXA },
        columnWidths: [1800, 3000, 4560],
        rows: [
          new TableRow({ children: [
            new TableCell({ borders: BORDERS, width: { size: 1800, type: WidthType.DXA },
              shading: { fill: DARK, type: ShadingType.CLEAR },
              margins: { top: 100, bottom: 100, left: 140, right: 140 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Product', bold: true, size: 20, color: WHITE, font: 'Arial' })] })] }),
            new TableCell({ borders: BORDERS, width: { size: 3000, type: WidthType.DXA },
              shading: { fill: DARK, type: ShadingType.CLEAR },
              margins: { top: 100, bottom: 100, left: 140, right: 140 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Purpose', bold: true, size: 20, color: WHITE, font: 'Arial' })] })] }),
            new TableCell({ borders: BORDERS, width: { size: 4560, type: WidthType.DXA },
              shading: { fill: DARK, type: ShadingType.CLEAR },
              margins: { top: 100, bottom: 100, left: 140, right: 140 },
              children: [new Paragraph({ children: [new TextRun({ text: 'Key Capabilities', bold: true, size: 20, color: WHITE, font: 'Arial' })] })] })
          ]}),
          ...([
            ['KYC', 'Identity verification for individuals', 'Document verification, MRZ extraction, NFC chip reading, face verification, liveness detection, voice biometrics, audit trail'],
            ['KYB', 'Business verification for legal entities', 'Company registry lookup, ownership structure mapping, UBO identification, director verification, sanctions screening'],
            ['eID Gateway', 'Single API for European Digital Identity Wallet acceptance', 'EU EUDIW credential verification, cross-border identity acceptance, eIDAS 2.0 alignment (designed for)'],
            ['Trust Engine', 'Risk scoring, AML screening, and decision intelligence', 'AML screening, PEP screening, sanctions screening, risk scoring, fraud detection, automated decision rules, audit trails, webhooks']
          ].map(([prod, purp, caps], idx) => new TableRow({
            children: [
              new TableCell({ borders: BORDERS, width: { size: 1800, type: WidthType.DXA },
                shading: idx%2===1 ? { fill: LIGHT, type: ShadingType.CLEAR } : undefined,
                margins: { top: 100, bottom: 100, left: 140, right: 140 },
                children: [new Paragraph({ children: [new TextRun({ text: prod, bold: true, size: 20, color: RED, font: 'Arial' })] })] }),
              new TableCell({ borders: BORDERS, width: { size: 3000, type: WidthType.DXA },
                shading: idx%2===1 ? { fill: LIGHT, type: ShadingType.CLEAR } : undefined,
                margins: { top: 100, bottom: 100, left: 140, right: 140 },
                children: [new Paragraph({ children: [new TextRun({ text: purp, size: 20, color: MID, font: 'Arial' })] })] }),
              new TableCell({ borders: BORDERS, width: { size: 4560, type: WidthType.DXA },
                shading: idx%2===1 ? { fill: LIGHT, type: ShadingType.CLEAR } : undefined,
                margins: { top: 100, bottom: 100, left: 140, right: 140 },
                children: [new Paragraph({ children: [new TextRun({ text: caps, size: 20, color: MID, font: 'Arial' })] })] })
            ]
          })))
        ]
      }),

      ...blank(),

      // ── TARGET MARKETS ────────────────────────────────────
      h2('Target Markets'),
      body('VerfiX is designed for regulated organisations that are required by law or by their customers to verify identity, assess risk, and maintain compliance documentation. The primary target markets are:'),

      new Table({
        width: { size: W, type: WidthType.DXA },
        columnWidths: [2400, 6960],
        rows: [
          headerRow(['Sector', 'Primary Use Cases'], [2400, 6960]),
          dataRow(['Banks', 'Customer onboarding (GwG Art. 3), KYC refresh, telephone banking authentication, UBO identification, AML screening'], [2400, 6960], false),
          dataRow(['Fintechs', 'Digital account opening, merchant onboarding, payment platform compliance, AML automation'], [2400, 6960], true),
          dataRow(['Crypto platforms', 'VASP compliance, FINMA Travel Rule, exchange onboarding, high-value wallet verification'], [2400, 6960], false),
          dataRow(['Insurance companies', 'Policyholder onboarding, claims identity verification, voice authentication for telephone services'], [2400, 6960], true),
          dataRow(['Telecom operators', 'SIM registration, subscriber identity verification, SIM-swap prevention'], [2400, 6960], false),
          dataRow(['Government agencies', 'Citizen identity verification, digital service onboarding, secure access control'], [2400, 6960], true),
          dataRow(['Universities', 'Student identity verification for remote examination, digital credential issuance'], [2400, 6960], false),
          dataRow(['Mobility providers', 'Driver verification, passenger onboarding, age and licence verification'], [2400, 6960], true),
          dataRow(['Regulated businesses', 'Any GwG-scope entity requiring documented client identification and AML screening'], [2400, 6960], false),
        ]
      }),

      ...blank(),

      // ── TECHNICAL OVERVIEW ────────────────────────────────
      h2('Technical Overview'),
      h3('Architecture Approach'),
      body('VerfiX is built as an API-first platform. All capabilities are exposed through a REST API, enabling integration with existing systems, core banking platforms, CRM tools, and custom onboarding workflows without requiring proprietary connectors. The platform is designed to function as infrastructure — not a standalone application — so that it augments and automates existing processes rather than replacing them.'),
      body('[Diagram: Architecture overview — Web/Mobile clients → REST API layer → KYC/KYB/Trust Engine modules → Swiss-hosted data layer → Audit trail storage]'),

      h3('Deployment Options'),
      bullet('Cloud (Swiss-hosted): Processing and storage in certified Swiss data centres. Fastest path to go-live. Recommended for most organisations.'),
      bullet('Private Cloud: Dedicated infrastructure for the customer within a Swiss-hosted environment. Higher isolation for sensitive use cases.'),
      bullet('On-Premise: Full deployment within the customer\'s own infrastructure. Designed for organisations with the strictest data control requirements.'),

      h3('Integration'),
      bullet('REST API with JSON request and response format'),
      bullet('API key and Bearer token authentication'),
      bullet('Webhooks for asynchronous event notification (verification completed, AML hit, risk score update)'),
      bullet('SDKs planned for Python, JavaScript, and Java'),
      bullet('Sandbox environment for integration testing prior to production go-live'),

      ...blank(),

      // ── REGULATORY POSITIONING ────────────────────────────
      h2('Regulatory and Compliance Positioning'),
      body('VerfiX is designed to support the compliance obligations of Swiss regulated entities. Key regulatory alignments:'),

      new Table({
        width: { size: W, type: WidthType.DXA },
        columnWidths: [3000, 6360],
        rows: [
          headerRow(['Regulation', 'VerfiX Alignment'], [3000, 6360]),
          dataRow(['FINMA Circular 2016/7', 'Platform is designed to meet remote identification requirements including document verification, biometric matching, and liveness detection'], [3000, 6360], false),
          dataRow(['GwG Art. 3 & 4', 'Designed to support customer and UBO identification obligations for financial intermediaries'], [3000, 6360], true),
          dataRow(['nFADP', 'All processing in Switzerland; biometric data handled as sensitive personal data; DPA available; designed for nFADP compliance'], [3000, 6360], false),
          dataRow(['GDPR', 'Platform architecture is designed to support GDPR obligations for organisations with EU data subjects'], [3000, 6360], true),
          dataRow(['eIDAS 2.0', 'eID Gateway product designed to accept EU Digital Identity Wallet credentials (planned for EU rollout timeline)'], [3000, 6360], false),
          dataRow(['FATF Recommendations', 'AML and sanctions screening capabilities designed to support FATF-aligned AML programme requirements'], [3000, 6360], true),
        ]
      }),

      ...blank(),

      // ── SECURITY ──────────────────────────────────────────
      h2('Security and Data Protection'),
      bullet('AES-256 encryption for all data at rest'),
      bullet('TLS 1.3 for all data in transit'),
      bullet('Role-based access control (RBAC) for all platform access'),
      bullet('Multi-factor authentication for administrative functions'),
      bullet('Immutable, cryptographically signed audit trail per verification event'),
      bullet('All data processed and stored exclusively in Switzerland'),
      bullet('Data Processing Agreement (DPA) available for all customers'),
      bullet('Sub-processor list maintained and updated with 30 days\' prior notice'),
      bullet('Incident response policy with 72-hour notification commitment'),
      bullet('Annual penetration testing programme (planned)'),

      ...blank(),

      // ── WHY VERFIX ───────────────────────────────────────
      h2('Why VerfiX'),

      new Table({
        width: { size: W, type: WidthType.DXA },
        columnWidths: [2800, 6560],
        rows: [
          headerRow(['Differentiator', 'What it Means for You'], [2800, 6560]),
          dataRow(['Swiss-first', 'Data never leaves Switzerland. No cross-border transfer risk. No FINMA data residency concern.'], [2800, 6560], false),
          dataRow(['Compliance built in', 'FINMA, nFADP, GwG requirements are addressed in the platform design — not added as configuration.'], [2800, 6560], true),
          dataRow(['API-first modularity', 'Use only what you need. KYC only, AML only, or the full stack. One integration, any combination.'], [2800, 6560], false),
          dataRow(['Fast integration', 'REST API with comprehensive documentation. Sandbox available immediately. Designed for 48-hour integration.'], [2800, 6560], true),
          dataRow(['Full audit trail', 'Every verification event logged, timestamped, and cryptographically signed. FINMA inspection ready.'], [2800, 6560], false),
          dataRow(['On-premise available', 'For organisations with the strictest data control requirements, full on-premise deployment is supported.'], [2800, 6560], true),
          dataRow(['Flexible deployment', 'Cloud, private cloud, or on-premise. Migration path between options as requirements evolve.'], [2800, 6560], false),
        ]
      }),

      ...blank(),

      // ── NEXT STEPS ────────────────────────────────────────
      h2('Next Steps'),
      body('VerfiX is available for enterprise evaluation. The following engagement options are available:'),
      bullet('Product demonstration: 30-minute call covering your specific use case and compliance requirements.'),
      bullet('Sandbox access: API credentials for integration testing in a non-production environment.'),
      bullet('Technical review: Architecture and security documentation provided on request.'),
      bullet('Data Processing Agreement: Standard DPA available immediately; enterprise-specific addenda on request.'),
      bullet('Proof of Concept: Structured evaluation programme for enterprise accounts.'),

      ...blank(),
      new Paragraph({
        children: [
          new TextRun({ text: 'To arrange a demonstration or request documentation:', size: 22, color: MID, font: 'Arial' })
        ],
        spacing: { before: 120, after: 60 }
      }),
      new Paragraph({
        children: [
          new TextRun({ text: 'contact@verfix.ch  |  verfix.ch  |  calendly.com/ahmed-ahmed-alsultan/30min', size: 22, bold: true, color: RED, font: 'Arial' })
        ],
        spacing: { before: 0, after: 240 }
      }),

      // ── CONFIDENTIALITY NOTICE ────────────────────────────
      new Paragraph({
        children: [new TextRun('')],
        border: { top: { style: BorderStyle.SINGLE, size: 2, color: 'CCCCCC', space: 1 } },
        spacing: { before: 480, after: 60 }
      }),
      new Paragraph({
        children: [new TextRun({
          text: 'Confidentiality Notice: This document contains proprietary and confidential information of VerfiX AG. It is provided solely for the purpose of evaluation and may not be reproduced, distributed, or disclosed to any third party without the prior written consent of VerfiX AG. All statements about planned or designed-for capabilities represent the company\'s current roadmap intentions and are not contractual commitments.',
          size: 16, color: MID, font: 'Arial', italics: true
        })],
        spacing: { before: 0, after: 60 }
      }),

    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/home/claude/verfix-docs/01-VerfiX-Company-Overview.docx', buffer);
  console.log('Done: 01-VerfiX-Company-Overview.docx');
});
